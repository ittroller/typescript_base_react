import React, { memo } from 'react';
import './privateCommon/layout.private.scss';

const PrivateLayout = props => {
  return <div className="private-layout">{props.children}</div>;
};
export default memo(PrivateLayout);
