import HeaderPublic from './header/Header.component';
import FooterPublic from './footer/Footer.component';

export { HeaderPublic, FooterPublic };
