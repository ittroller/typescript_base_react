import { lazy } from 'react';
import { PrivateLayout } from '../layouts';
const DashboardContainer = lazy(() => import('../modules').then(module => ({ default: module.DashboardContainer })));
const AccountContainer = lazy(() => import('../modules').then(module => ({ default: module.AccountContainer })));

const privateRouters = {
  layout: PrivateLayout,
  type: 'private',
  subRoutes: [
    {
      path: '/dashboard',
      component: DashboardContainer,
      exact: true,
      isAuth: true,
    },
    {
      path: '/account',
      component: AccountContainer,
      exact: true,
      isAuth: true,
    },
  ],
};

export default privateRouters;
