import privateRouter from './privateRouter';
import publicRouter from './publicRouter';

export { privateRouter, publicRouter };
