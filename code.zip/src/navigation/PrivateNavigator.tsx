import React, { lazy, useEffect, memo } from 'react';
import { Route, Switch, useHistory, useLocation } from 'react-router-dom';

import { privateRouter, publicRouter } from '../router';

const NotFound = lazy(() => import('../modules').then(module => ({ default: module.NotFound })));

const PrivateNavigator = () => {
  const mergeRoute = [privateRouter, publicRouter];
  const location = useLocation();
  const history = useHistory();

  useEffect(() => {
    if (publicRouter?.subRoutes?.length) {
      publicRouter.subRoutes.map(route => {
        if (route.path === location.pathname && (location.pathname === '/login' || location.pathname === '/register')) {
          return history.push('/dashboard');
        }
        return false;
      });
    }
  }, [history, location]);

  return (
    <Switch>
      {mergeRoute.map((route, i) => (
        <Route key={i} exact={route.subRoutes.some(r => r.exact)} path={route.subRoutes.map(r => r.path)}>
          <privateRouter.layout>
            {route.subRoutes.map((subRoute, idx) => (
              <Route key={idx} {...subRoute} />
            ))}
          </privateRouter.layout>
        </Route>
      ))}

      <Route exact component={NotFound} />
    </Switch>
  );
};

export default memo(PrivateNavigator);
