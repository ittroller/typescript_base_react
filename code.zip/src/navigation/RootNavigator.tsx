import React, { useMemo, memo } from 'react';
import { useSelector } from 'react-redux';

import PrivateNavigator from './PrivateNavigator';
import PublicNavigator from './PublicNavigator';
import ResolveNavigator from './ResolveNavigator';

import { privateRouter, publicRouter } from '../router';
import { useLocation } from 'react-router-dom';
import { useState } from 'react';

const RootNavigator = () => {
  const [hasUser, setHasUser] = useState(useSelector(state => !!state.global.user));
  const location = useLocation();

  const renderUI = useMemo(() => {
    const isLogin = !!localStorage.getItem('token');

    const isRouterPrivate = privateRouter?.subRoutes.find(route => route.path === location.pathname);

    const isAuthenRouter = publicRouter?.subRoutes.find(
      route => route.path === location.pathname && (route.path === '/login' || route.path === '/register'),
    );

    const setUser = user => setHasUser(user);

    if (hasUser) return <PrivateNavigator />;
    else if (isLogin && (isRouterPrivate || isAuthenRouter)) return <ResolveNavigator setUser={setUser} />;
    return <PublicNavigator />;
  }, [hasUser, location]);

  return <>{renderUI}</>;
};

export default memo(RootNavigator);
