import React, { lazy, memo } from 'react';
import { Route, Switch, useHistory, useLocation } from 'react-router-dom';

import { publicRouter, privateRouter } from '../router';

const NotFound = lazy(() => import('../modules').then(module => ({ default: module.NotFound })));

const PublicNavigator = () => {
  const location = useLocation();
  const history = useHistory();

  return (
    <Switch>
      <Route exact={publicRouter.subRoutes.some(r => r.exact)} path={publicRouter.subRoutes.map(r => r.path)}>
        <publicRouter.layout>
          {publicRouter.subRoutes.map((subRoute, idx) => (
            <Route key={idx} {...subRoute} />
          ))}
        </publicRouter.layout>
      </Route>
      {privateRouter?.subRoutes?.length ? (
        privateRouter.subRoutes.map(route => {
          if (route.path === location.pathname) {
            return history.push('/login');
          } else return <Route exact key={'NOT FOUND'} component={NotFound} />;
        })
      ) : (
        <Route exact component={NotFound} />
      )}
    </Switch>
  );
};

export default memo(PublicNavigator);
