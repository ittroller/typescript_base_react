import { takeEvery, put, call } from 'redux-saga/effects'; // put
import { USER_TYPE } from './global.type';
import { USER_ACTION } from './global.action';
import GLOBAL_API from './global.api';
import { Functional } from '../../utils';

function* onGetUser(params) {
  try {
    const { user = {}, callback = () => {} } = params;
    const userData = yield GLOBAL_API.getUserAPI(user);
    if (userData) {
      yield put(USER_ACTION.getUserSuccess(user));
      callback(userData);
    }
    //  else {
    //   callback('/login');
    // }
  } catch (error) {
    const newError = yield call(Functional.generateMessage, error);
    console.log(newError);
  }
}

export function* globalSaga() {
  yield takeEvery(USER_TYPE.GET_USER_REQUEST, onGetUser);
}
