import { takeEvery, put } from 'redux-saga/effects';

const SET_LOADING = 'SET_LOADING';

const setLoading = action => ({ type: SET_LOADING, action });

const initialState = {
  isLoading: false,
  type: '',
};

const loadingReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_LOADING:
      return { ...state, isLoading: action.isLoading, type: action.type };
    default:
      return state;
  }
};

function* onSetLoading(action) {
  yield put(setLoading(action));
}

function* loadingSaga() {
  yield takeEvery(SET_LOADING, onSetLoading);
}

export { loadingReducer, setLoading, loadingSaga };
