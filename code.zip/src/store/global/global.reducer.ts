import { USER_TYPE } from './global.type';

const initialState = {
  user: null,
};

const globalReducer = (state = initialState, action) => {
  switch (action.type) {
    case USER_TYPE.GET_USER_SUCCESS:
      return { ...state, user: action.user, isLogin: true };
    default:
      return state;
  }
};

export default globalReducer;
