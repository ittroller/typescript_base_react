import AccountContainer from './Account.container';

export { AccountContainer };
