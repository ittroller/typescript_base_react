import AccountComponent from './Account.component';

export { AccountComponent };
