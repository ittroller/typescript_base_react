import React, { memo } from 'react';

const AccountComponent = () => {
  return <div>ACCOUNT</div>;
};

export default memo(AccountComponent);
