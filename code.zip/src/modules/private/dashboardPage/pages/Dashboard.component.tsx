import React, { memo } from 'react';

const DashboardComponent = () => {
  return <div className="Home">/1 DASH BOARD</div>;
};

export default memo(DashboardComponent);
