import DashboardContainer from './Dashboard.container';

export { DashboardContainer };
