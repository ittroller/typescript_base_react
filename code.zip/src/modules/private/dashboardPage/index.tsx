import { DashboardContainer } from './containers';

export { DashboardContainer };
