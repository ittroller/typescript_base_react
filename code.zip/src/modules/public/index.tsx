export * from './authPage';
export * from './homePage';
export * from './aboutPage';
export * from './blogsPage';
