const COUNT_UP = 'COUNT_UP';
const COUNT_DOWN = 'COUNT_DOWN';

export { COUNT_UP, COUNT_DOWN };
