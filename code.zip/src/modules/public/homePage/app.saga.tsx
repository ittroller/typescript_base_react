import { put, delay, takeEvery } from 'redux-saga/effects';
import { onCountDown, onCountUp } from './app.action';
import { COUNT_DOWN, COUNT_UP } from './app.types';

function* countUp() {
  yield delay(1000);
  yield put(onCountUp);
}

function* countDown() {
  yield delay(1000);
  yield put(onCountDown);
}

export function* appSaga() {
  yield takeEvery(COUNT_UP, countUp);
  yield takeEvery(COUNT_DOWN, countDown);
}
