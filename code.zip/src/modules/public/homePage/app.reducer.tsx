import { COUNT_UP, COUNT_DOWN } from './app.types';

const initialState = 0;

const count = (state = initialState, action) => {
  switch (action.type) {
    case COUNT_UP:
      return state + 1;
    case COUNT_DOWN:
      return state - 1;
    default:
      return state;
  }
};

export default count;
