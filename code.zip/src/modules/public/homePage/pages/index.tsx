import HomeComponent from './Home.component';

export { HomeComponent };
