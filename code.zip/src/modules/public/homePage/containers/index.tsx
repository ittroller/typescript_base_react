import HomeContainer from './Home.container';

export { HomeContainer };
