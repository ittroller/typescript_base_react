import { memo } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import { LOGIN_ACTION } from '../auth.action';
import { LoginComponent, RegisterComponent } from '../pages';

const mapStateToProps = state => ({ ...state });

const mapDispatchToProps = dispatch =>
  bindActionCreators({ onLogin: LOGIN_ACTION.onLoginRequest, onRegister: LOGIN_ACTION.onLoginRequest }, dispatch);

export default {
  LoginContainer: memo(connect(mapStateToProps, mapDispatchToProps)(LoginComponent)),
  RegisterContainer: memo(connect(mapStateToProps, mapDispatchToProps)(RegisterComponent)),
};
