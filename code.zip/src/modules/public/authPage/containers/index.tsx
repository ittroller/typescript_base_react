import RegisterContainer from './Auth.container';
import LoginContainer from './Auth.container';
// import AuthContainer from './Auth.container';

export { RegisterContainer, LoginContainer };
