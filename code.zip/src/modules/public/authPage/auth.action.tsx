import { LOGIN_TYPE, LOGOUT_TYPE, REGISTER_TYPE } from './auth.types';

const LOGIN_ACTION = {
  onLoginRequest: (data, callback) => ({ type: LOGIN_TYPE.LOGIN_REQUEST, data, callback }),
  onLoginSucces: (data, callback) => ({ type: LOGIN_TYPE.LOGIN_SUCCESS, data, callback }),
  onLoginFailure: (data, callback) => ({ type: LOGOUT_TYPE.LOGOUT_FAILURE, data, callback }),
};

const LOGOUT_ACTION = {
  onLogoutRequest: (data, callback) => ({ type: LOGOUT_TYPE.LOGOUT_REQUEST, data, callback }),
  onLogoutSucces: (data, callback) => ({ type: LOGOUT_TYPE.LOGOUT_SUCCESS, data, callback }),
  onLogoutFailure: (data, callback) => ({ type: LOGOUT_TYPE.LOGOUT_FAILURE, data, callback }),
};

const REGISTER_ACTION = {
  onRegisterRequest: data => ({ type: REGISTER_TYPE.REGISTER_REQUEST, data }),
  onRegisterSuccess: data => ({ type: REGISTER_TYPE.REGISTER_SUCCESS, data }),
  onRegisterFailure: data => ({ type: REGISTER_TYPE.REGISTER_FAILURE, data }),
};

export { LOGIN_ACTION, LOGOUT_ACTION, REGISTER_ACTION };
