import { get } from 'lodash';
import Service from '../../../services';

const AUTH_API = {
  loginAPI: async params => {
    const response = await Service.post(`/api/user/login`, params);
    const data = get(response, 'data', null);
    return data;
  },
};

export default AUTH_API;
