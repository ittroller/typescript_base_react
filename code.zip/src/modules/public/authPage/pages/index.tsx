import LoginComponent from './Login.component';
import RegisterComponent from './Register.component';

export { LoginComponent, RegisterComponent };
