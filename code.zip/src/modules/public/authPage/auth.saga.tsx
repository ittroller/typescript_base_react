import { takeEvery, put, call } from 'redux-saga/effects';

import { LOGIN_TYPE, REGISTER_TYPE, LOGOUT_TYPE } from './auth.types';
import AUTH_API from './auth.api';
import { USER_ACTION } from '../../../store/global';
import { Functional } from '../../../utils';

function* loginFunc(action) {
  try {
    const { data, callback } = action;
    const user = yield call(AUTH_API.loginAPI, data);

    if (user) {
      localStorage.setItem('token', user.token);
      localStorage.setItem('refresh_token', user.refresh_token);
      yield put(USER_ACTION.getUserSuccess(user));
      callback();
    }
  } catch (error) {
    const newError = yield call(Functional.generateMessage, error);
    console.log(newError);
  }
}

function* logoutFunc() {
  try {
    localStorage.removeItem('token');
    localStorage.removeItem('refresh_token');
    yield console.log('logout');
  } catch (error) {
    console.log(error);
  }
}

function* registerFunc() {
  //   try {
  //     const { email, password, redirectTo } = action.data;
  //     yield call([firebase.auth(), firebase.auth().createUserWithEmailAndPassword], email, password);
  //     redirectTo();
  //   } catch (error) {
  //     console.log(error);
  //   }
}

export function* authSaga() {
  yield takeEvery(LOGIN_TYPE.LOGIN_REQUEST, loginFunc);
  yield takeEvery(LOGOUT_TYPE.LOGOUT_REQUEST, logoutFunc);
  yield takeEvery(REGISTER_TYPE.REGISTER_REQUEST, registerFunc);
}
