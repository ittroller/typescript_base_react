import { AboutContainer } from './containers';
// import appReducer from './app.reducer';
// import { appSaga } from './app.saga';
// import * as homeAction from './app.action';

export { AboutContainer };
// export { appReducer, appSaga, homeAction };
