import AboutContainer from './About.container';

export { AboutContainer };
