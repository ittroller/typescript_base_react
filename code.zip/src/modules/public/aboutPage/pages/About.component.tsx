import React, { memo } from 'react';

const AboutComponent = () => {
  return <div className="about-page">About</div>;
};

export default memo(AboutComponent);
