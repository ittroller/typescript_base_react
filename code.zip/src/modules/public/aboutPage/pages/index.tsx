import AboutComponent from './About.component';

export { AboutComponent };
