import BlogsComponent from './Blogs.component';

export { BlogsComponent };
