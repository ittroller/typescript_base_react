import React, { memo } from 'react';

const BlogsComponent = () => {
  return <div className="blogs-page">Blogs</div>;
};

export default memo(BlogsComponent);
