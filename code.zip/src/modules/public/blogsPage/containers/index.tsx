import BlogsContainer from './Blogs.container';

export { BlogsContainer };
