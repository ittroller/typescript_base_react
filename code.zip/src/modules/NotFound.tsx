import React from 'react';

const NotFound = () => {
  return <div className="notfound-layout">404 PAGE</div>;
};

export { NotFound };
