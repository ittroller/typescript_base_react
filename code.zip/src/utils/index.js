import Functional from './Functional';
import LocalStorage from './Storage';

export { LocalStorage, Functional };
